import pytest
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options

URL = "https://testqastudio.me/"

def test_smoke(browser):
    """
    Test case WERT-1
    """
	
    browser.get(url = URL)
    
    element = browser.find_element(by=By.CSS_SELECTOR, value='[class="razzi-posts__found-inner"]')
    
    assert element.text == 'Показано 12 из 17 товары', \
        'Неожиданный текст в подвале. Должны быть "Показано 12 из 17 товары"'


def test_sku(browser):
    """
    Test Case - 02 check SKU
    """

    browser.get(url = URL)

    browser.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    import time
    time.sleep(2)

    element = browser.find_element(by=By.CSS_SELECTOR, value=f'[class*="post-11346"]')
    element.click()

    sku = browser.find_element(by=By.CLASS_NAME, value= "sku")

    assert sku.text == 'K46LK6TB55', 'Unexpected SKU, must be "K46LK6TB55" '


def test_product_view_sku(browser):
    """
    Test case WERT-1
    """


    browser.get(url=URL)

    element = browser.find_element(by=By.CSS_SELECTOR, value="[class*='tab-best_sellers']")
    element.click()
		
    element = browser.find_element(by=By.CSS_SELECTOR, value='[class*="post-11340"]')
    element.click()
	
    sku = browser.find_element(By.CLASS_NAME, value="sku")

    assert sku.text == 'BFB9ZOK210', "Unexpected sku"